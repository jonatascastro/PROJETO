   $(document).ready( function(){
               $("#enviar_cadastro_simples").click(function (){
                    $('#erro').show();
                      setTimeout(function(){     
                        $('#erro').hide();
                      }, 3000); // 3000 = 3 segundos
                 }); 
               }); 
               
           $(document).ready( function(){
               $("#enviar_cadastro").click(function (){
                    $('#erro').show();
                      setTimeout(function(){     
                        $('#erro').hide();
                      }, 3000); // 3000 = 3 segundos
                 }); 
               });
               
 $(document).ready(function(){
  
    $('#cpf').mask('00000000000000');
    $('#telefone').mask('(00)0000-0000');
    $('#celular').mask('(00)00000-0000');
    $('#cep').mask('00000-000');
    $('#data_nascimento').mask('00/00/0000');

});
    

            
            
  function mostrar(){
  var tipo = document.getElementById("senha1");
  var tipo2 = document.getElementById("senha2");



  if (tipo.type === "password") {
    tipo.type = "text";
  } else {
    tipo.type = "password";
  }
 

  tipo2.type = tipo.type; //aplica o tipo que ficou no primeiro campo

 
}



