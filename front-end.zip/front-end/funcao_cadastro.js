



        
 function confirmar(texto, callback1, callback2){
  var confirmacao = confirm(texto);
  if(confirmacao) callback1(); // executa a primeira função de "OK"
  else callback2(); // executa a segunda função se "Cancelar"
}
        
     function fimSessao(){ 
 
        confirmar(
            "Deseja finalizar sua sessão?",
       function(){
        var valor= 01;	   
          var vUrl = "listar.php?sair="+valor;
          $.get(
           vUrl, //Required URL of the page on server
          
            function(response,status)
           {
             // tratando o status de retorno. Sucesso significa que o envio e retorno foi executado com sucesso.
             if(status ==="success")
             {
                 alert('Sessão finalizada com sucesso!');
                  window.location.replace('index.php');
             }    	
           }
          );
            
           },
           function(){
                  alert("Sessão não finalizada!");  
                 
           }
         );  
    
        };
        
   
        
     
        
        
        
 function  listar(){ 
  var html="";
  var imagem="";
    $.ajax({
        type:'post',
        url:"salvar.php",  
        dataType: 'json',
         beforeSend: function (xhr) {
           
         },        
        success: function(dados){
 
   
        var tamanhoPagina = 16;
        var pagina = 0;

     function paginar(){
                  

    for (var i = pagina * tamanhoPagina; i < dados.length && i < (pagina + 1) *  tamanhoPagina; i++) {
    
                       imagem ="<img src='pastaimagem/"+dados[i].imagem+"' width='40' height='40'>";
               
                       html +="<tr>\
                       <td>"+dados[i].id+"</td>\
                       <td>"+dados[i].nome_completo+"</td>\
                       <td>"+dados[i].apelido+"</td>\
                       <td>"+dados[i].cpf+"</td>\
                       <td>"+dados[i].sexo+"</td>\
                       <td>"+dados[i].data_nascimento+"</td>\
                       <td>"+dados[i].estado+"</td>\
                       <td>"+dados[i].email+"</td>\
                       <td>"+dados[i].cidade+"</td>\
                       <td>"+dados[i].cep+"</td>\
                       <td>"+dados[i].telefone+"</td>\
                       <td>"+dados[i].celular+"</td>\
                       <td>"+dados[i].usuario+"</td>\
                       <td>"+dados[i].senha+"</td>\
                       <td>"+imagem+"</td></tr>";
                           
                           
    $("#mostra").html(html);  
    $("#usuario").text(dados[i].apelido);
    
      
    }
    
    html="";
    
     $('#numeracao').text('Página ' + (pagina + 1) + ' de ' + Math.ceil(dados.length / tamanhoPagina));
   

}


function ajustarBotoes() {
    $('#proximo').prop('disabled', dados.length <= tamanhoPagina || pagina >= Math.ceil(dados.length / tamanhoPagina) - 1);
    $('#anterior').prop('disabled', dados.length <= tamanhoPagina || pagina == 0);
}

$(function() {
    $('#proximo').click(function() {
        if (pagina < dados.length / tamanhoPagina - 1) {
            pagina++;
            paginar();
            ajustarBotoes();
        }
    });
    $('#anterior').click(function() {
        if (pagina > 0) {
            pagina--;
            paginar();
            ajustarBotoes();
        }
    });
    paginar();
    ajustarBotoes();
});
            
            
            } 
                             
           
      });
    

   };  
        
    


  $(document).ready(function(){    
   
   listar();

  $("#cep").blur(function() {
        
      var cep= document.getElementById("cep").value;  
 if(cep==''){
     
     alert("Campo CEP está vazio, favor preecher!");
     
     
 }else{    
      var vUrl = "https://viacep.com.br/ws/"+cep+"/json/";
       $.ajax({
        type:'GET',
        url:vUrl,  
        dataType: 'json',
         beforeSend: function (xhr) {
             $("#consutar_cep_formulario").show();
             $("#consutar_cep_formulario").text("carregando...");
             
         },
        success: function(response){
                if(response.cep)
             {
                 
               $("#consutar_cep_formulario").hide();
               $.each(response, function(){
	        $("#estado").val(response['uf']);
               $("#cidade").val(response['localidade']+'-'+response['uf']);
               $("#bairro").val(response['bairro']);
               $("#endereco").val(response['logradouro']);
              
                   
            }); 
            
             }if(response.erro){
                $("#consutar_cep_formulario").hide();
                alert("Ops! CEP não identificado, favor verificar.");
                
                
           }
            },error:function(){
                $("#consutar_cep_formulario").hide();
               alert("Ops! ocorreu algum erro");
           }
        });
    }
   });
   });     










        
   function cadastra(){ 
     
     
       var sexo = $("input[name='sexo']:checked").val();
  
       
       $("#enviar").click(function(){ 
     
           var form_data = new FormData();   
           var file_data = $('#img').prop('files')[0];   
    
           var nome_completo =$("#nome_completo").val();
           var apelido = $("#apelido").val();
           var telefone = $("#telefone").val();
           var cpf = $("#cpf").val();
           var data_nascimento = $("#data_nascimento").val();
           var estado = $("#estado").val();
           var email = $("#email").val();
           var cidade = $("#cidade").val();
           var cep = $("#cep").val();
           var celular = $("#celular").val();
           var usuario = $("#usuario").val();
           var senha1 = $("#senha1").val();
           var senha2 = $("#senha2").val();
           
           form_data.append('img', file_data);
           form_data.append('nome_completo', nome_completo);
           form_data.append('apelido', apelido);
           form_data.append('telefone', telefone);
           form_data.append('cpf', cpf);
           form_data.append('data_nascimento', data_nascimento);
           form_data.append('estado', estado);
           form_data.append('email', email);
           form_data.append('cidade', cidade);
           form_data.append('cep', cep);
           form_data.append('celular', celular);
           form_data.append('usuario', usuario);
           form_data.append('sexo', sexo);
           form_data.append('senha1', senha1);
           form_data.append('senha2', senha2);
     
           
          if(senha1!=senha2){
              
              alert("favor verificar a senha!");

                return false;
          } 
           else{
        $.ajax({			//Função AJAX
                url:"salvar.php",			//Arquivo php
                type:"post",	
                dataType:'json',//Método de envio
                cache: false,
                contentType: false,
                processData: false,
                data: form_data,	//Dados
                beforeSend: function (result) {
                    
                    $('#myModalEditar').modal('show');
                },
                success: function (result){			//Sucesso no AJAX                      
                    
                if(result==1){		
           
                     $('#myModalEditar').modal('hide');
                      listar();
                                    alert('Cadastro relizado com sucesso!');
                                   
                }
                if(result==2){
                     $('#myModalEditar').modal('hide');
                         alert("Ops! O e-mail, cpf informado já cadastrado!");

                }
                       
                },
                erro:function (result){
                  $('#myModalEditar').modal('hide');
                  alert("erro!");
                }
	     });
             
         }
        
        });  
        };   
        
        

 
               
     function logar(){ 
          
          var emailAdmin= $("#email").val();
          var passwordAdmin= $("#senha").val();
        
          
          if(emailAdmin===""||passwordAdmin===""){
              alert("Favor Preencher os Campos em Brancos!");
            
          }else{
        	$.ajax({			//Função AJAX
			url:"salvar.php",			//Arquivo php
			type:"post",				//Método de envio
			dataType:'json',//Método de envio
                        data:{senha:passwordAdmin,email:emailAdmin},	//Dados
   			success: function (result){			//Sucesso no AJAX
                		if(result==1){						
                			  location.href='listar.php';//Redireciona//Redireciona
                		}
                                else if(result==2){
                                           alert('E-mail ou Senha Incorreto!'); //Informa o erro
                                            
                		}
            		}, erro:function (){
                            
                           alert("Erro!"); 
                        }
		});
          }
        };
        
        
    