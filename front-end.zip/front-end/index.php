
<html>
    <head>
        
        <title>Login</title>
        <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
        <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
        <!------ Include the above in your HEAD tag ---------->
        <!--Pulling Awesome Font -->
        
        <link href="tela_login.css" rel="stylesheet" type="text/css"/>
        <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
      
        <script src="funcao_cadastro.js" type="text/javascript"></script>
        
        <style>
         body {
            font-family: 'Montserrat';
          }
        </style>
        
    </head>
    <body>
        

            <div class="container-fluid" style="margin-top: 100px" >
              <div class="row" >
                  <div class="col-md-3" style="margin-top: 100px"></div>
                  <div class=" col-md-5">
                      <div class="form-login">
                      <h4>Login</h4>
                      <input type="email" id="email" name="userName"class="form-control input-sm chat-input" placeholder="E-mail" />
                      </br>
                      <input type="password" id="senha" class="form-control input-sm chat-input" placeholder="Senha" />
                      </br>
                      <div class="wrapper">
                      <span class="group-btn">     
                          <a href="#" onclick="logar()" class="btn btn-primary btn-md">Acessar <i class="fa fa-sign-in"></i></a>
                      </span>
                      </div>
                     
                      </div>

                  </div>
              </div>
          </div>
   
    </body>    
    
</html>