
 <?php 
 error_reporting(0);
  // A sessão precisa ser 
     session_start();
    

    // Verifica se não há a variável da sessão que identifica o usuário
    if($_SESSION['cpf']=="") {
        // Destrói a sessão por segurança

        // Redireciona o visitante de volta pro login
      header ('location:index.php');  

    }
    if(isset($_GET['sair'])){
    if($_GET['sair'] =='01')
    {
       unset( $_SESSION['cpf'] );
       unset( $_SESSION['apelido'] );
       unset( $_SESSION["imagem"]);
        header ('location:index.php');  


    }
    }




?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Listar</title>
  

           <meta charset="utf-8">
           <meta name="viewport" content="width=device-width, initial-scale=1">
           <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css">
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


           <link rel="shortcut icon" href="../logo.png" type="image/x-png"/>
           <link href="bootstrap_css.css" rel="stylesheet" type="text/css"/>
           <script src="funcao_cadastro.js" type="text/javascript"></script>
           <script src="jquery.mask.js" type="text/javascript"></script>
           <script src="mensagem_cadastro.js" type="text/javascript"></script>
<style>
    .footer{width:100%; float:left; background:black; height:100px; margin-top:250px}
    body {
    font-family: 'Montserrat';
     }
    img {
  border-radius: 50%;
}
</style>

 <style>

            body {
            font-family: 'Montserrat';
             }
    


            .alert-message
            {
                margin: 20px 0;
                padding: 20px;
                border-left: 3px solid #eee;
            }
            .alert-message h4
            {
                margin-top: 0;
                margin-bottom: 5px;
            }
            .alert-message p:last-child
            {
                margin-bottom: 0;
            }
            .alert-message code
            {
                background-color: #fff;
                border-radius: 3px;
            }
            .alert-message-success
            {
                background-color: #F4FDF0;
                border-color: #3C763D;
            }
            .alert-message-success h4
            {
                color: #3C763D;
            }
            .alert-message-danger
            {
                background-color: #fdf7f7;
                border-color: #d9534f;
            }
            .alert-message-danger h4
            {
                color: #d9534f;
            }
            .alert-message-warning
            {
                background-color: #fcf8f2;
                border-color: #f0ad4e;
            }
            .alert-message-warning h4
            {
                color: #f0ad4e;
            }
            .alert-message-info
            {
                background-color: #f4f8fa;
                border-color: #5bc0de;
            }
            .alert-message-info h4
            {
                color: #5bc0de;
            }
            .alert-message-default
            {
                background-color: #EEE;
                border-color: #B4B4B4;
            }
            .alert-message-default h4
            {
                color: #000;
            }
            .alert-message-notice
            {
                background-color: #FCFCDD;
                border-color: #BDBD89;
            }
            .alert-message-notice h4
            {
                color: #444;
            }

        
            
        </style>
</head>


<body >

    


<nav class="navbar navbar-inverse col-xl-12 col-md-12 col-lg-12" style="background: black;border-radius: 0px;">
    <br>
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>	  
     
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
          <li><a href="listar.php"><span class="glyphicon glyphicon-home"></span> Início</a></li>  
          
         <li class="dropdown">
            
            <ul class="dropdown-menu">                
                 
                    
            </ul>
       </li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
          <li><a href="#"  onclick="fimSessao()"><span class="glyphicon glyphicon-log-out"></span>Sair</a></li>
      </ul>
    </div>
  </div>
</nav>  

 <div class="container-fluid">   
        <div class="row">
            <div class="col-xl-12 col-md-12 ">
                <label>
                    <img src="pastaimagem/<?php echo  $_SESSION["imagem"]?>" class="rounded-circle " width="40" height="40">
                </label>
                     <a data-toggle="tab" href="#home">Usuário: <?php echo $_SESSION['apelido']?> </a>
                 </div> 
             </div> 
           </div> 
    <br><br>
    <div class="container-fluid">   
        <div class="row">
            <div class="col-xl-12 col-md-12 col-lg-12">
            <ul class="nav nav-tabs " >
                 <li class="active"><a data-toggle="tab" href="#home"><i  class="fa fa-envelope"  aria-hidden="true"></i>Contato</a></li>
                 <li><a data-toggle="tab" href="#cadastro"><i class="fa fa-id-card" aria-hidden="true"></i>Cadastro</a></li>
            
            </ul>
    </div>
  </div>        
  </div>
<div class="tab-content">
  <div id="home" class="tab-pane fade in active">
   <!--  tabela de  email solicitando o serviço-->
   

        <div class="container-fluid" >
         <div class="row" > 
          <div class="table-responsive col-xs-12 col-md-12" align="center"> 
              <br><br>
           <h2>Tabela</h2>
           <p>Lista de usuários</p> 

           <table id="example"class="table table-striped table-bordered" style="width:100%">
             <thead >
              <tr class="bg-primary">
                <th style="background: #a2aec7; color: #ffffff; text-align: center;">id</th> 
                <th style="background: #a2aec7; color: #ffffff; text-align: center;">N. Completo</th>
                <th style="background: #a2aec7; color: #ffffff; text-align: center;">Apelido</th> 
                <th style="background:#a2aec7; color: #ffffff; text-align: center;">CPF</th> 
                <th style="background: #a2aec7; color: #ffffff; text-align: center;">Sexo</th> 
                <th style="background: #a2aec7; color: #ffffff; text-align: center;">Data N.</th> 
                <th style="background: #a2aec7; color: #ffffff; text-align: center;">Estado</th>
                <th style="background: #a2aec7; color: #ffffff; text-align: center;">E-mail</th>
                <th style="background: #a2aec7; color: #ffffff; text-align: center;">Cidade</th> 
                <th style="background:#a2aec7; color: #ffffff; text-align: center;">CEP</th> 
                <th style="background: #a2aec7; color: #ffffff; text-align: center;">Telefone</th> 
                <th style="background:#a2aec7; color: #ffffff; text-align: center;">Celular</th> 
                <th style="background: #a2aec7; color: #ffffff; text-align: center;">Usuário</th> 
                <th style="background: #a2aec7; color: #ffffff; text-align: center;">Senha</th> 
                <th style="background: #a2aec7; color: #ffffff; text-align: center;">Imagem</th> 
              </tr>
            </thead>
            <tbody align="center"id="mostra">
            
                
            </tbody>
          </table>
        </div>
        </div>
      </div>
      <div class="col-md-12 col-xs-12">
       <br>
         <button id="anterior"   class="btn btn-danger" disabled> <span aria-hidden="true">&laquo; Anterior</span>
            <span class="sr-only"></span></button>
            <span id="numeracao"></span>
        <button id="proximo"   class="btn btn-danger" disabled> Próximo  <span aria-hidden="true">&raquo;</span>
            <span class="sr-only"></span></button>
   </div>  

  </div>
    
    
    <div id="cadastro" class="tab-pane fade ">
        
        
           <br><br>

    <div class="container">
      <div class="row">
          <div class="col-xs-12 col-md-3 col-sm-12"></div>
      <div class="col-xs-12 col-md-6">
          <div align="center" class="alert-message alert-message-warning">
              <h4  >Formulário de cadastro</h4>
               
            </div>
          </div>   
      </div>
    </div>
 
 
      
        <div class="container">
          <div class="row"></div>
          <div class="col-md-3 col-xs-12" ></div>
          <div class="col-md-6 col-xs-12" id="erro" align="center" ></div>

      </div>
        
      <hr>

      <div class="container-fluid " >
            <div class="col-xs-12  col-md-2" style="left: 14px" >    
                     <label>Seleciona o Sexo: </label> 
                     <div class="input-group"> 
                           <input  onclick="cadastra();" type="radio"  name="sexo"  value="M" />Masculino
                           <br>
                           <input  onclick=" cadastra();" type="radio" name="sexo"   value="F"  />Feminino
                          
                    </div>
                  </div>

          <form  class="form-horizontal col-xs-12 col-md-10 "  id="simples" >
             
             <fieldset>
                 
                <div class="col-xs-12 col-md-4"> 
                <label >Imagem perfil:</label>  
                     <div class="input-group">
                  <div class="input-group-addon">
                         <i class="glyphicon glyphicon-picture" aria-hidden="true"></i>
                     </div>
                         
                         <input  id="img" type="file" class="form-control" >
                    </div>
                  </div>

               <div class="col-xs-12 col-md-4"> 
                <label >Nome Completo:</label>  
                     <div class="input-group">
                  <div class="input-group-addon">
                         <i class="glyphicon glyphicon-user" aria-hidden="true"></i>
                     </div>
                         
                         <input  id="nome_completo" type="text" class="form-control" >
                    </div>
                  </div>
                 
                 <div class="col-xs-12 col-md-4"> 
                <label >Apelido:</label>  
                     <div class="input-group">
                  <div class="input-group-addon">
                         <i class="glyphicon glyphicon-user" aria-hidden="true"></i>
                     </div>
                         
                         <input  id="apelido" type="text" class="form-control" >
                    </div>
                  </div>
     
             

      
             <!-- Text input-->
              
               <div class="col-xs-12 col-md-4" > 
                <label >CPF:</label>  
                     <div class="input-group">
                  <div class="input-group-addon">
                         <i class="glyphicon glyphicon-home" aria-hidden="true"></i>
                     </div>
                        <input id="cpf" maxlength="14"  type="text" class="form-control" >
                    </div>
                  </div>
             
             
         
              
               <div class="col-xs-12 col-md-4"> 
                <label >Data nascimento:</label>  
                     <div class="input-group">
                  <div class="input-group-addon">
                         <i class="glyphicon glyphicon-envelope" aria-hidden="true"></i>
                     </div>
                         <input  id="data_nascimento" type="text" class="form-control" >
                    </div>
                  </div>
             
               <div class="col-xs-12 col-md-4"> 
                <label >CEP:</label>  
                     <div class="input-group">
                  <div class="input-group-addon">
                         <i class="glyphicon glyphicon-envelope" aria-hidden="true"></i>
                     </div>
                         <input  id="cep" type="text" class="form-control" >
                    </div>
                  </div>
             
               <div class="col-xs-12 col-md-4"> 
                <label >Estado:</label>  
                     <div class="input-group">
                  <div class="input-group-addon">
                         <i class="glyphicon glyphicon-envelope" aria-hidden="true"></i>
                     </div>
                         <input  id="estado" type="text" class="form-control" >
                    </div>
                  </div>
             
               <div class="col-xs-12 col-md-4"> 
                <label >E-mail:</label>  
                     <div class="input-group">
                  <div class="input-group-addon">
                         <i class="glyphicon glyphicon-envelope" aria-hidden="true"></i>
                     </div>
                         <input  id="email" type="email" class="form-control" >
                    </div>
                  </div>
             
                  
             
             
             
               <div class="col-xs-12 col-md-4"> 
                <label >Cidade:</label>  
                     <div class="input-group">
                  <div class="input-group-addon">
                         <i class="glyphicon glyphicon-envelope" aria-hidden="true"></i>
                     </div>
                         <input  id="cidade" type="text" class="form-control" >
                    </div>
                  </div>
      
             
             
               <div class="col-xs-12 col-md-4"> 
                <label >Celular:</label>  
                     <div class="input-group">
                  <div class="input-group-addon">
                         <i class="glyphicon glyphicon-envelope" aria-hidden="true"></i>
                     </div>
                         <input  id="celular" type="text" class="form-control" >
                    </div>
                  </div>
             
                <div class="col-xs-12 col-md-4"> 
                <label >telefone:</label>  
                     <div class="input-group">
                  <div class="input-group-addon">
                         <i class="glyphicon glyphicon-envelope" aria-hidden="true"></i>
                     </div>
                         <input  id="telefone" type="text" class="form-control" >
                    </div>
                  </div>
             
               <div class="col-xs-12 col-md-4"> 
                <label >Usuário:</label>  
                     <div class="input-group">
                  <div class="input-group-addon">
                         <i class="glyphicon glyphicon-envelope" aria-hidden="true"></i>
                     </div>
                         <input  id="usuario" type="text" class="form-control" >
                    </div>
                  </div>
            
    

       
           
           <div class=" col-md-4 col-sm-12"> 
                <label >Senha:</label>  
                     <div class="input-group">
                    <div class="input-group-addon">
                         <i class="fa fa-key" aria-hidden="true"></i>
                     </div>
                         <input id="senha1"  type="password" class="form-control"  >
                       
                     <div class="input-group-addon" onclick="mostrar()">
                        <i title="Visualizar" class="glyphicon glyphicon-eye-open" aria-hidden="true" ></i>
                     </div>
                    </div>
                  </div>
             
              <div class="col-md-4  col-sm-12"> 
                <label >Confirmar Senha:</label>  
                 <div class="input-group">
                  <div class="input-group-addon">
                         <i class="fa fa-key" aria-hidden="true"></i>
                     </div>
                          <input id="senha2"  type="password" class="form-control"  >
                     <div class="input-group-addon" onclick="mostrar()">
                       <i  title="Visualizar"  aria-hidden="true" class="glyphicon glyphicon-eye-open" ></i>
                     </div>
                  </div>
                
                  </div>
             
             <!-- Button (Double) -->
             <div class="form-group"> 
               <label class="col-xs-12 col-md-12" ></label>
               <div class="col-md-12" align="center">         
                   <br>
                   <a href="#ancora"> <button type="button" id="enviar" class="btn btn-warning" ><span class="glyphicon glyphicon-floppy-save"></span> Enviar</button></a>
               </div>
             </div>

             </fieldset>
             </form>
        
         <!-- daqui para baixo panos complexos-->
    
 </div>
    </div>
    
    

  
</div> 

    <hr>
    <footer class="footer">
    
        
        
   </footer>

</body>
</html>