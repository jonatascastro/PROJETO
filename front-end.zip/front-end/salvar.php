
<?php

session_start();
 include_once ("config.php");
 error_reporting(0);
$conn = new mysqli(DB_SERVIDOR ,DB_USUARIO, DB_SENHA, DB_BANCO);  

if(isset($_POST['senha'])){   
          
            $email = $_POST['email'];
            $senha = $_POST ['senha']; 

            $pesquisa_email= ("SELECT  * FROM cadastro WHERE email = ('$email') AND senha =('$senha') ");
            $pesquisa_feita = $conn->query($pesquisa_email);          
            $numero_linha = mysqli_num_rows($pesquisa_feita);  

if($numero_linha >0){  
 
           

      while($pega_id= mysqli_fetch_assoc($pesquisa_feita)){//comando para pegar todos cadastro no banco     
            $_SESSION["cpf"]= $pega_id['cpf'];   
            $_SESSION["apelido"]= $pega_id['apelido'];  
            $_SESSION["imagem"]= $pega_id['imagem'];  
      } 
      echo 1;  
      exit();
    
} else {
                  
        echo 2;
        exit();
}

}

    

         
         
if(isset($_POST['sexo'])){   

            $imagem = $_FILES['img'];
            $sexo = $_POST['sexo'];
            $nome_completo = $_POST['nome_completo'];
            $email = $_POST['email']; 
            $usuario = $_POST['usuario'];
            $senha1 = $_POST['senha1'];
            $senha2 = $_POST['senha2'];
            $apelido = $_POST['apelido'];
            $data_nascimento = $_POST['data_nascimento'];
            $estado = $_POST['estado'];
            $telefone = $_POST['telefone'];
            $cpf = $_POST['cpf'];
            $cep = $_POST['cep'];
            $celular = $_POST['celular'];
            $cidade = $_POST['cidade'];
          
       
            
           $verificar_email = ("SELECT  email, cpf FROM cadastro WHERE email = ('$email') OR cpf=('$cpf')");
           $buscar_no_branco = $conn->query($verificar_email);  
                    
            $verificar_se_existe= mysqli_num_rows($buscar_no_branco);
            
            if($verificar_se_existe ==0){
  
                $target_dir = "pastaimagem/";
                $new_name=$_FILES["img"]["name"];
                $target_file = $target_dir . basename($_FILES["img"]["name"]);
                 move_uploaded_file($_FILES["img"]["tmp_name"], $target_file);
              
                
            $insere = ("INSERT INTO  cadastro (nome_completo,imagem,apelido, cpf, sexo, data_nascimento, estado,email, "
             ."cidade,cep,telefone, celular,usuario,senha) "
             . "VALUES ('$nome_completo','$new_name','$apelido', '$cpf','$sexo','$data_nascimento', '$estado','$email',"
             . "'$cidade','$cep','$telefone','$celular','$usuario','$senha1')");
             $conn->query($insere);        
                 echo 1;
                 exit();


            }
          else{
                
                 echo 2;
                 exit();
                
            }
            
         }
  
// esse local é para gera json das ofertas que usuário posta////
    $pesquisa_ofertas= ("SELECT *  FROM cadastro ");
    $pesquisa= $conn->query($pesquisa_ofertas);   
   
    
      while ($exibir= mysqli_fetch_assoc($pesquisa)) { 
         $dados[] = array(
             'id'=>$exibir['id'],
             'nome_completo'=>$exibir['nome_completo'],
             'apelido'=>$exibir['apelido'],
             'cpf'=>$exibir['cpf'],
             'sexo'=>$exibir['sexo'],
             'data_nascimento'=>$exibir['data_nascimento'],
             'estado'=>$exibir['estado'],
             'email'=>$exibir['email'],
             'cidade'=>$exibir['cidade'],
             'cep'=>$exibir['cep'],
             'telefone'=>$exibir['telefone'],
             'celular'=>$exibir['celular'],
             'usuario'=>$exibir['usuario'],
             'senha'=>$exibir['senha'],     
             'imagem'=>$exibir['imagem'],     
          
         ); 

            }
      
                
               echo json_encode($dados);
$conn->close();