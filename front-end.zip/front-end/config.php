
<?php
        
        define("DB_SERVIDOR","localhost");
	define("DB_USUARIO","root");
	define("DB_SENHA","");
	define("DB_BANCO","frnt_end");
	

	


     